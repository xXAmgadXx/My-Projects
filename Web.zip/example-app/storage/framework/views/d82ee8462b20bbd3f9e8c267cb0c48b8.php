<footer>
    <p>&copy; <?php echo date("Y"); ?> User Registration. All rights reserved. | Contact us at support@example.com</p>
    <p>Follow us on social media: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
</footer>


<?php /**PATH C:\Users\adhmh\OneDrive\Desktop\example-app\resources\views/footer.blade.php ENDPATH**/ ?>