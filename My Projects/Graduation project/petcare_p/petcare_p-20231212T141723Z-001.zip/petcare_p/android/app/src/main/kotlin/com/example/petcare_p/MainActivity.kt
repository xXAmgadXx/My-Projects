package com.example.petcare_p

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
